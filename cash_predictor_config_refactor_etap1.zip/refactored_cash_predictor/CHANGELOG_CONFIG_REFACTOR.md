# Config refactor - Etap 1

## Dodane pliki

- `config/schema.py` - typowany dataclass `Settings`.
- `config/loader.py` - ładowanie ENV / `.env` / lokalnych defaultów, casting i walidacja.
- `config/settings.py` - globalny singleton `settings = load_settings()`.
- `.env.example` - lokalny szablon konfiguracji bez sekretów.

## Zmienione pliki

- `runner_batch.py`
  - domyślne ścieżki i parametry pochodzą z `settings`, nie z hardcode CLI,
  - `--model-path`, `--db-path`, `--results-file`, `--config` mają defaulty z ENV,
  - odczyt klientów korzysta z warstwy `database.get_connection()`.

- `database.py`
  - dodano obsługę `DB_URL=sqlite:///...` przez centralne `settings`,
  - `get_connection()` może używać globalnego DB path/URL,
  - log level pochodzi z ENV.

- `db_init.py`
  - `--config` i `--db-path` mają defaulty z `settings`,
  - inicjalizacja bazy może działać jako osobny krok/pseudo-aplikacja DB initializer.

- `build_client_dbs.py`
  - domyślny config i DB path pochodzą z `settings`,
  - wywołanie `db_init.py` jest niezależne od bieżącego katalogu.

- `build_dataset_db.py`
  - domyślny DB path pochodzi z `settings`,
  - log level pochodzi z ENV.

- `first_model.py`
  - `MODEL_PATH`, `BATCH_SIZE`, `EPOCHS`, `LEARNING_RATE`, katalog wag pochodzą z `settings`,
  - usunięto aktywne hardcoded ścieżki Windows dla outputu wag.

- `config.yaml`
  - usunięto aktywne lokalne ścieżki Windows,
  - ustawiono lokalne, relatywne defaulty.

## Uwaga

Ten refactor jest etapem konfiguracji. Kod nadal zachowuje lokalną zgodność ze SQLite, ale konfiguracja jest gotowa na `DB_URL=postgresql://...` w kolejnym etapie migracji. Pełne przełączenie SQL runtime na PostgreSQL wymaga osobnego etapu warstwy bazy / SQLAlchemy / Alembic.
