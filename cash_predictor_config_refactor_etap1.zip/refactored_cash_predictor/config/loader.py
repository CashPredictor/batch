from __future__ import annotations

import os
from pathlib import Path
from urllib.parse import urlparse, unquote

from .schema import Settings

_ALLOWED_ENVS = {"local", "dev", "test", "prod"}


def _load_dotenv_if_available() -> None:
    """Load .env for local runs without making python-dotenv a hard dependency."""
    try:
        from dotenv import load_dotenv  # type: ignore
    except ImportError:
        return
    load_dotenv()


def _getenv(name: str, default: str | None = None) -> str | None:
    value = os.getenv(name)
    if value is None or value == "":
        return default
    return value


def _get_bool(name: str, default: bool) -> bool:
    raw = _getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


def _get_int(name: str, default: int) -> int:
    raw = _getenv(name)
    if raw is None:
        return default
    return int(raw)


def _get_float(name: str, default: float) -> float:
    raw = _getenv(name)
    if raw is None:
        return default
    return float(raw)


def sqlite_path_from_db_url(db_url: str) -> str | None:
    """Return filesystem path for sqlite:/// URLs. Non-SQLite URLs return None.

    This keeps the current SQLite code running locally while the same config field
    can later point to postgresql://... in GCP/Cloud SQL.
    """
    if not db_url.startswith("sqlite://"):
        return None
    parsed = urlparse(db_url)
    if parsed.netloc and parsed.path:
        # sqlite://host/path is not expected for this app.
        return unquote(parsed.path)
    path = unquote(parsed.path or "")
    if path.startswith("/") and not db_url.startswith("sqlite:////"):
        # sqlite:///relative.db is parsed as /relative.db; strip only the URL slash.
        path = path[1:]
    return path or "local.db"


def load_settings() -> Settings:
    _load_dotenv_if_available()

    env = _getenv("ENV", "local") or "local"
    default_db_url = "sqlite:///local.db" if env == "local" else None
    db_url = _getenv("DB_URL", default_db_url)

    settings = Settings(
        ENV=env,
        DB_URL=db_url or "",
        LOG_LEVEL=_getenv("LOG_LEVEL", "INFO") or "INFO",
        JOB_ID=_getenv("JOB_ID", "local-run") or "local-run",
        BATCH_SIZE=_get_int("BATCH_SIZE", 32),
        LOCAL_DATA_PATH=_getenv("LOCAL_DATA_PATH", "./data") or "./data",
        MODEL_PATH=_getenv("MODEL_PATH", "./models/first_model.pt") or "./models/first_model.pt",
        RESULTS_FILE=_getenv("RESULTS_FILE", "./model_runs.xlsx") or "./model_runs.xlsx",
        WEIGHTS_OUTPUT_DIR=_getenv("WEIGHTS_OUTPUT_DIR", "./data/wagi") or "./data/wagi",
        EPOCHS=_get_int("EPOCHS", 10),
        LEARNING_RATE=_get_float("LEARNING_RATE", 0.001),
        ENABLE_CLASSIFICATION_HEAD=_get_bool("ENABLE_CLASSIFICATION_HEAD", True),
        CONFIG_PATH=_getenv("CONFIG_PATH", "config.yaml") or "config.yaml",
        DB_PATH=_getenv("DB_PATH", sqlite_path_from_db_url(db_url or "")),
        TEST_DB_PATH=_getenv("TEST_DB_PATH", None),
    )
    validate(settings)
    return settings


def validate(settings: Settings) -> None:
    if settings.ENV not in _ALLOWED_ENVS:
        raise ValueError(f"Invalid ENV '{settings.ENV}'. Allowed values: {sorted(_ALLOWED_ENVS)}")
    if not settings.DB_URL:
        raise ValueError("DB_URL is required")
    if settings.BATCH_SIZE <= 0:
        raise ValueError("BATCH_SIZE must be greater than 0")
    if settings.EPOCHS <= 0:
        raise ValueError("EPOCHS must be greater than 0")
    if settings.LEARNING_RATE <= 0:
        raise ValueError("LEARNING_RATE must be greater than 0")

    if settings.ENV != "local" and settings.DB_URL.startswith("sqlite://"):
        raise ValueError("SQLite DB_URL is allowed only for ENV=local")

    for path_value in [settings.LOCAL_DATA_PATH, settings.MODEL_PATH, settings.RESULTS_FILE, settings.WEIGHTS_OUTPUT_DIR]:
        if path_value:
            parent = Path(path_value).parent if Path(path_value).suffix else Path(path_value)
            parent.mkdir(parents=True, exist_ok=True)
