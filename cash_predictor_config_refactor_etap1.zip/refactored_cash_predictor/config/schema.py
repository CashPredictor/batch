from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class Settings:
    # --- ENV ---
    ENV: str

    # --- DATABASE ---
    DB_URL: str

    # --- LOGGING ---
    LOG_LEVEL: str

    # --- BATCH ---
    JOB_ID: str
    BATCH_SIZE: int

    # --- STORAGE ---
    LOCAL_DATA_PATH: str
    MODEL_PATH: str
    RESULTS_FILE: str
    WEIGHTS_OUTPUT_DIR: str

    # --- ML ---
    EPOCHS: int
    LEARNING_RATE: float

    # --- FEATURE SWITCHES ---
    ENABLE_CLASSIFICATION_HEAD: bool

    # --- OPTIONAL LOCAL COMPATIBILITY ---
    CONFIG_PATH: str
    DB_PATH: Optional[str] = None
    TEST_DB_PATH: Optional[str] = None
